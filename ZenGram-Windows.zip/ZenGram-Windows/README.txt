========================================================
 ZenGram for Windows (10 / 11)
 Distraction-Free Instagram for Aspirants & Creators
========================================================

HOW TO RUN:
1. Double-click "ZenGram-Windows.bat"
2. ZenGram launches directly in dedicated standalone app mode (Edge App Mode).
   - Zero install required!
   - 100% feed & explore free
   - Direct to Direct Messages (/direct/inbox/)

Have Node.js installed?
You can also run in command prompt:
   npx zengram
